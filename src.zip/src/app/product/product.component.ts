import { Component, OnInit } from '@angular/core';
import { Http, Response } from '@angular/http';

// import SampleJson from '../../assets/SampleJson.json';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  constructor(private http: Http) {
    // console.log(SampleJson);
  }
  confirmationString: string = 'New Product has been Added !!';
  isAdded: boolean = false;
  productObj: object = [];
  // arrBirds:object =  [];

  private headers = new Headers({ 'Content-Type': 'application/json' });

  Users: object = [];

  addiotnalData:any;


  addNewProduct = function(product) {
    this.productObj = {
      ID: product.p_id,
      Title: product.p_name,
      PageCount: product.p_cost,
      Description: product.p_desc,
      Excerpt: product.p_excerpt

    };
    // this.http
      // .post('/assets/SampleJson.json', this.productObj)
      // .subscribe((res: Response) => {
      //   this.Users = res.json();
      //   console.log('Hey--> + this.Users');
      //   this.isAdded = true;
      // });

    // this.http.post('http://fakerestapi.azurewebsites.net/api/Books', this.productObj)
    //   .subscribe((res: Response) => { 
    //     this.Users = res.json();
    //     this.isAdded = true;
    //     // this.Users.push(this.productObj);
    //     console.log('NewData-->' + this.Users);
    //   },
    //   (err: Error) => {
    //     console.log (err.message);
    //   }
    // );

    
    this.http.post('http://localhost:3000/employees', 
            this.productObj, { headers: this.headers })
      .subscribe((res: Response) => { 
        this.Users = res.json();
        this.isAdded = true;
        // this.Users.push(this.productObj);
        console.log('NewData-->' + this.Users);
      },
      (err: Error) => {
        console.log (err.message);
      }
    );

    
  };

  ngOnInit() {
    
  }
}
